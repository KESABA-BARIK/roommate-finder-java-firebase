package com.example.hostelroommatefinder.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.hostelroommatefinder.ChatActivity;
import com.example.hostelroommatefinder.R;
import com.example.hostelroommatefinder.models.User;

import java.util.List;

public class RoomAdapter extends RecyclerView.Adapter<RoomAdapter.ViewHolder> {

    public interface OnRoommateClickListener {
        void onRoommateClick(User user);
    }

    private Context context;
    private List<User> userList;

    private OnRoommateClickListener listener;

    public RoomAdapter(Context context, List<User> userList) {
        this.context = context;
        this.userList = userList;
    }
    public RoomAdapter(Context context, List<User> roommateList, OnRoommateClickListener listener) {
        this.context = context;
        this.userList = roommateList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_room, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        User user = userList.get(position);
        holder.tvName.setText(user.getName());
        holder.tvAge.setText("Age: " + user.getAge());
        holder.tvGender.setText("Gender: " + user.getGender());
        holder.tvInterests.setText("Interests: " + user.getInterests());
        holder.tvPreferences.setText("Preferences: " + user.getPreferences());// Keep only necessary fields

        // Handle item click to start chat
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, ChatActivity.class);
            intent.putExtra("receiverId", user.getUserId());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return userList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvAge, tvGender, tvInterests, tvPreferences;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvName);
            tvAge = itemView.findViewById(R.id.tvAge);
            tvGender = itemView.findViewById(R.id.tvGender);
            tvInterests = itemView.findViewById(R.id.tvInterests);
            tvPreferences = itemView.findViewById(R.id.tvPreferences);
        }
    }
}

